# MotionGraphs

This sample demonstrates how to receive updates from sensors using Core Motion. It displays graphs of accelerometer, gyroscope and device motion data.

## Requirements

### Build

Xcode 8.0 or later; iOS 10.0 SDK or later

### Runtime

iOS 10.0 or later


Copyright (C) 2016 Apple Inc. All rights reserved.
